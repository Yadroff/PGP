#pragma once

#include "Engine/object.h"

class objCIRCLE : public engOBJECT
{
public:
	objCIRCLE(float r, int segmentsNum = 8);
};
