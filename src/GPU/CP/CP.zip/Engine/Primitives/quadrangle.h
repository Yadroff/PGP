#pragma once
#include "Engine/object.h"

class objQUADRANGLE : public engOBJECT
{
public:
	objQUADRANGLE(const vec3 vert[4]);
};
